from pathlib import Path
import tempfile

from app.config import Settings
from app.safety.allowlist import CommandAllowlist
from app.safety.sandbox import WorkspaceSandbox
from app.tools.exec_tools import ExecTools

with tempfile.TemporaryDirectory() as temporary:
    root = Path(temporary) / "workspace"
    root.mkdir()
    (root / "visible.txt").write_text("contained\n")
    settings = Settings(workspace_root=root, sqlite_path=Path(temporary) / "harness.db", audit_log_path=Path(temporary) / "audit.log")
    sandbox = WorkspaceSandbox(settings)
    tool = ExecTools(settings, sandbox, CommandAllowlist(settings, sandbox))
    print(tool.execute(["ls"], dry_run=False))
